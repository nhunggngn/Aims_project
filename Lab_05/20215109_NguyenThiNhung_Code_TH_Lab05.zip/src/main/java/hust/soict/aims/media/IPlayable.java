package hust.soict.aims.media;

public interface IPlayable {
    public void play();
}
